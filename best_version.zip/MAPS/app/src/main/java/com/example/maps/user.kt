package com.example.maps

data class user(val firstname : String? = null,val lastname : String? = null,val age : String? = null,val userName : String? = null){

}
